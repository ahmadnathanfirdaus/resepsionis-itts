<?php $__env->startSection('main'); ?>
    <h5>Pending <span class="bg-info text-light px-1 rounded"><?php echo e(count($pendingAppointments)); ?></span></h5>
    <table class="table">
        <thead>
            <th>#</th>
            <th>Nama</th>
            <th>Institusi</th>
            <th>Email</th>
            <th>Nomor Telepon</th>
            <th>Keperluan</th>
            <th>Tanggal Kedatangan</th>
            <th>Action</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pendingAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i + 1); ?></td>
                    <td><?php echo e($appointment->visitor->name); ?></td>
                    <td><?php echo e($appointment->visitor->institution); ?></td>
                    <td><?php echo e($appointment->visitor->email); ?></td>
                    <td><?php echo e($appointment->visitor->phone); ?></td>
                    <td><?php echo e($appointment->purpose); ?></td>
                    <td><?php echo e($appointment->arrival_date); ?></td>
                    <td>
                        <form action="<?php echo e(route('admin.approve', ['appointment' => $appointment])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-success" onclick="return confirm('Approve?')">Approve</button>
                        </form>
                    </td>
                    <td>
                        <form action="<?php echo e(route('admin.deny', ['appointment' => $appointment])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-danger" onclick="return confirm('Deny?')">Deny</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <h5>Approved <span class="bg-success text-light px-1 rounded"><?php echo e(count($approvedAppointments)); ?></span></h5>
    <table class="table">
        <thead>
            <th>#</th>
            <th>Nama</th>
            <th>Institusi</th>
            <th>Email</th>
            <th>Nomor Telepon</th>
            <th>Keperluan</th>
            <th>Tanggal Kedatangan</th>
            <th>Status</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $approvedAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i + 1); ?></td>
                    <td><?php echo e($appointment->visitor->name); ?></td>
                    <td><?php echo e($appointment->visitor->institution); ?></td>
                    <td><?php echo e($appointment->visitor->email); ?></td>
                    <td><?php echo e($appointment->visitor->phone); ?></td>
                    <td><?php echo e($appointment->purpose); ?></td>
                    <td><?php echo e($appointment->arrival_date); ?></td>
                    <td class="fw-bold text-success"><?php echo e($appointment->status); ?> </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <h5>Denied <span class="bg-danger text-light px-1 rounded"><?php echo e(count($deniedAppointments)); ?></span></h5>
    <table class="table">
        <thead>
            <th>#</th>
            <th>Nama</th>
            <th>Institusi</th>
            <th>Email</th>
            <th>Nomor Telepon</th>
            <th>Keperluan</th>
            <th>Tanggal Kedatangan</th>
            <th>Status</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $deniedAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i + 1); ?></td>
                    <td><?php echo e($appointment->visitor->name); ?></td>
                    <td><?php echo e($appointment->visitor->institution); ?></td>
                    <td><?php echo e($appointment->visitor->email); ?></td>
                    <td><?php echo e($appointment->visitor->phone); ?></td>
                    <td><?php echo e($appointment->purpose); ?></td>
                    <td><?php echo e($appointment->arrival_date); ?></td>
                    <td class="fw-bold text-danger"><?php echo e($appointment->status); ?> </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ahmadnathanfirdaus/Projects/Website/resepsionis/resources/views/admin/appointment.blade.php ENDPATH**/ ?>
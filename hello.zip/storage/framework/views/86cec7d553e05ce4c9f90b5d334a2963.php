<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($title); ?></title>
    
    <link rel="stylesheet" href="/css/bootstrap.min.css">
    <?php echo $__env->yieldContent('head'); ?>
</head>

<body>
    <?php echo $__env->yieldContent('body'); ?>

    <div class="content p-3">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    
    <script src="/js/bootstrap.min.js"></script>
    
    <script src="/js/popper.min.js"></script>
    
    <script src="/js/jquery.js"></script>
    
    <script src="https://kit.fontawesome.com/8a58851d5d.js" crossorigin="anonymous"></script>
</body>

</html>
<?php /**PATH /Users/ahmadnathanfirdaus/Projects/Website/resepsionis/resources/views/layouts/app.blade.php ENDPATH**/ ?>
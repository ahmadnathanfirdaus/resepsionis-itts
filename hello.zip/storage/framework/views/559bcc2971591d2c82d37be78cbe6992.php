    
    <script src="js/bootstrap.min.css"></script>
    
    <script src="js/popper.min.css"></script>
    
    <script src="js/jquery.css"></script>
    
    <script src="https://kit.fontawesome.com/8a58851d5d.js" crossorigin="anonymous"></script>
<?php /**PATH /Users/ahmadnathanfirdaus/Projects/Website/resepsionis/resources/views/layouts/script.blade.php ENDPATH**/ ?>
<?php $__env->startSection('main'); ?>
    <table class="table">
        <thead>
            <th>#</th>
            <th>Nama</th>
            <th>Institusi</th>
            <th>Email</th>
            <th>Nomor Telepon</th>
            <th>Keperluan</th>
            <th>Tanggal Kedatangan</th>
            <th>Status</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i + 1); ?></td>
                    <td><?php echo e($appointment->visitor->name); ?></td>
                    <td><?php echo e($appointment->visitor->institution); ?></td>
                    <td><?php echo e($appointment->visitor->email); ?></td>
                    <td><?php echo e($appointment->visitor->phone); ?></td>
                    <td><?php echo e($appointment->purpose); ?></td>
                    <td><?php echo e($appointment->arrival_date); ?></td>
                    <td>
                        <span class="fw-bold <?php echo e($appointment->status == 'approved' ? 'text-success' : 'text-danger'); ?>">
                            <?php echo e($appointment->status); ?>

                        </span>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ahmadnathanfirdaus/Projects/Website/resepsionis/resources/views/admin/visitor.blade.php ENDPATH**/ ?>
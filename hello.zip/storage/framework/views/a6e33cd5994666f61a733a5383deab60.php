<?php $__env->startSection('main'); ?>
    <div class="row gx-2 text-light text-center">
        <div class="col-md-4">
            <div class="bg-success rounded p-5">
                <h4>Total Visitor</h4>
                <h1><?php echo e(count($visitors)); ?></h1>
            </div>
        </div>
        <div class="col-md-4">
            <div class="bg-primary rounded p-5">
                <h4>Total Appointment</h4>
                <h1><?php echo e(count($appointments)); ?></h1>
            </div>
        </div>
        <div class="col-md-4">
            <div class="bg-danger rounded p-5">
                <h4>Pending Appointment</h4>
                <h1><?php echo e(count($appointments->where('status', 'pending'))); ?></h1>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ahmadnathanfirdaus/Projects/Website/resepsionis/resources/views/admin/index.blade.php ENDPATH**/ ?>

<link rel="stylesheet" href="css/bootstrap.min.css">
<?php /**PATH /Users/ahmadnathanfirdaus/Projects/Website/resepsionis/resources/views/layouts/style.blade.php ENDPATH**/ ?>
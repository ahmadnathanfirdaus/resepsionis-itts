@extends('layouts.admin')

@section('main')
    <div class="row gx-2 text-light text-center">
        <div class="col-md-4">
            <div class="bg-success rounded p-5">
                <h4>Total Visitor</h4>
                <h1>{{ count($visitors) }}</h1>
            </div>
        </div>
        <div class="col-md-4">
            <div class="bg-primary rounded p-5">
                <h4>Total Appointment</h4>
                <h1>{{ count($appointments) }}</h1>
            </div>
        </div>
        <div class="col-md-4">
            <div class="bg-danger rounded p-5">
                <h4>Pending Appointment</h4>
                <h1>{{ count($appointments->where('status', 'pending')) }}</h1>
            </div>
        </div>
    </div>
@endsection
